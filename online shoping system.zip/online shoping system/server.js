const express = require('express');
const db = require('./config/db');
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('./config/models/routes/public'));

app.use('/auth', require('./config/models/routes/authroutes'));
app.use('/products', require('./config/models/routes/ptoductroutes'));
app.use('/orders', require('./config/models/routes/orderroutes'));

app.listen(3000, () => console.log('Server running'));