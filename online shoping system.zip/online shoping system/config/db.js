const mysql = require('mysql2');

// Create connection to MySQL database
const db = mysql.createConnection({
  host: 'localhost',       // your MySQL host
  user: 'root',            // your MySQL username
  password: '',            // your MySQL password
  database: 'online_shopping'  // database name
});

// Connect to MySQL
db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err.message);
    return;
  }
  console.log('Connected to MySQL database!');
});

module.exports = db;