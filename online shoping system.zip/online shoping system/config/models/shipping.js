const db = require('../config/db');

const Shipping = {

  create: (data, callback) => {
    const sql = `
      INSERT INTO shipping (order_id, address, status)
      VALUES (?, ?, ?)
    `;
    db.query(sql, [
      data.order_id,
      data.address,
      data.status
    ], callback);
  },

  findByOrder: (orderId, callback) => {
    db.query(
      'SELECT * FROM shipping WHERE order_id = ?',
      [orderId],
      callback
    );
  }

};

module.exports = Shipping;