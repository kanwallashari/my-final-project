const express = require('express');
const bcrypt = require('bcrypt');
const db = require('../../db');
const router = express.Router();

router.post('/register', async (req, res) => {
  const hashed = await bcrypt.hash(req.body.password, 10);
  db.query(
    'INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)',
    [req.body.name, req.body.email, hashed, 'customer'],
    () => res.send('Registered')
  );
});

router.post('/login', (req, res) => {
  db.query(
    'SELECT * FROM users WHERE email=?',
    [req.body.email],
    async (err, result) => {
      if (result.length &&
          await bcrypt.compare(req.body.password, result[0].password)) {
        res.send('Login Success');
      } else {
        res.send('Invalid Credentials');
      }
    }
  );
});

module.exports = router;