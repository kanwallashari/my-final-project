const express = require('express');
const db = require('../../db');
const router = express.Router();

router.post('/create', (req, res) => {
  db.query(
    'INSERT INTO orders (user_id,total,status) VALUES (?,?,?)',
    [req.body.user, req.body.total, 'Pending'],
    (err, result) => res.json({ orderId: result.insertId })
  );
});

module.exports = router;