const express = require('express');
const router = express.Router();
const Category = require('../models/Category');

// Add a new category
router.post('/add', (req, res) => {
  Category.create({ category_name: req.body.category_name }, (err, result) => {
    if (err) return res.status(500).send(err);
    res.send('Category Added Successfully');
  });
});

// Get all categories
router.get('/', (req, res) => {
  Category.getAll((err, data) => {
    if (err) return res.status(500).send(err);
    res.json(data);
  });
});

module.exports = router;