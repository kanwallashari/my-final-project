const express = require('express');
const db = require('../../db');
const router = express.Router();

router.get('/', (req, res) => {
  db.query('SELECT * FROM products', (err, data) => res.json(data));
});

router.post('/add', (req, res) => {
  db.query(
    'INSERT INTO products (product_name,price,stock,category_id) VALUES (?,?,?,?)',
    [req.body.name, req.body.price, req.body.stock, req.body.category],
    () => res.send('Product Added')
  );
});

module.exports = router;