const db = require('../config/db');

const Order = {

  // Create a new order
  create: (data, callback) => {
    const sql = `
      INSERT INTO orders (user_id, total, status)
      VALUES (?, ?, ?)
    `;
    db.query(sql, [data.user_id, data.total, data.status], callback);
  },

  // Get all orders for a user
  findByUser: (userId, callback) => {
    const sql = `
      SELECT o.*, 
             SUM(oi.quantity * p.price) AS total_amount
      FROM orders o
      JOIN order_items oi ON o.order_id = oi.order_id
      JOIN products p ON oi.product_id = p.product_id
      WHERE o.user_id = ?
      GROUP BY o.order_id
    `;
    db.query(sql, [userId], callback);
  },

  // Get single order by ID
  findById: (orderId, callback) => {
    const sql = `
      SELECT o.*, u.name AS user_name, u.email AS user_email
      FROM orders o
      JOIN users u ON o.user_id = u.user_id
      WHERE o.order_id = ?
    `;
    db.query(sql, [orderId], callback);
  }

};

module.exports = Order;