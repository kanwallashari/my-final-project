const db = require('../config/db');

const Payment = {

  create: (data, callback) => {
    const sql = `
      INSERT INTO payments (order_id, method, status)
      VALUES (?, ?, ?)
    `;
    db.query(sql, [
      data.order_id,
      data.method,
      data.status
    ], callback);
  },

  findByOrder: (orderId, callback) => {
    db.query(
      'SELECT * FROM payments WHERE order_id = ?',
      [orderId],
      callback
    );
  }

};

module.exports = Payment;