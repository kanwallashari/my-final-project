const db = require('../config/db');

const Category = {

  create: (data, callback) => {
    db.query(
      'INSERT INTO categories (category_name) VALUES (?)',
      [data.category_name],
      callback
    );
  },

  getAll: (callback) => {
    db.query(
      'SELECT * FROM categories',
      callback
    );
  }

};

module.exports = Category;