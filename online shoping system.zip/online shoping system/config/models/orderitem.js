const db = require('../config/db');

const OrderItem = {

  create: (data, callback) => {
    const sql = `
      INSERT INTO order_items (order_id, product_id, quantity)
      VALUES (?, ?, ?)
    `;
    db.query(sql, [
      data.order_id,
      data.product_id,
      data.quantity
    ], callback);
  },

  findByOrder: (orderId, callback) => {
    db.query(
      `SELECT oi.*, p.product_name 
       FROM order_items oi
       JOIN products p ON oi.product_id = p.product_id
       WHERE oi.order_id = ?`,
      [orderId],
      callback
    );
  }

};

module.exports = OrderItem;