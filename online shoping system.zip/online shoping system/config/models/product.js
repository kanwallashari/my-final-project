const db = require('../config/db');

const Product = {

  create: (data, callback) => {
    const sql = `
      INSERT INTO products 
      (product_name, price, stock, category_id)
      VALUES (?, ?, ?, ?)
    `;
    db.query(sql, [
      data.product_name,
      data.price,
      data.stock,
      data.category_id
    ], callback);
  },

  getAll: (callback) => {
    db.query(
      `SELECT p.*, c.category_name 
       FROM products p 
       JOIN categories c ON p.category_id = c.category_id`,
      callback
    );
  },

  findById: (id, callback) => {
    db.query(
      'SELECT * FROM products WHERE product_id = ?',
      [id],
      callback
    );
  }

};

module.exports = Product;